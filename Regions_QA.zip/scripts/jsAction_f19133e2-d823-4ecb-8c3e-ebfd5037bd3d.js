﻿var file = new java.io.File("C:\\Users\\Mishra Prashant\\Documents\\NeoLoad Projects\\Regions_QA\\Logs\\L&D_FCP.txt");
var writer = new java.io.FileWriter(file,true);

var value = context.variableManager.getValue("CurrentDateVariable_1");

var count = context.variableManager.getValue("Counter");

writer.write("FCP  " + count + ">>   " + value + "\n");


//writer.write("abcde");
writer.close();

//logger.debug("Values" + value + "Returned Value");